AMATISTA — Demo oficial (visual) - empaquetado

Contenido:
- index.html, styles.css, script.js
- /mujer/fragancias/*.html
- /hombre/fragancias/*.html
- /assets/images/products/... (placeholders SVG)
- nosotros.html, contacto.html

IMPORTANTE: Reemplaza los archivos SVG en assets/images/products/... por tus fotos reales y optimizadas.
Para publicar: sube la carpeta raíz al repositorio GitHub y activa GitHub Pages (branch main, root /).

Si quieres que reemplace las imágenes por las tuyas, súbelas y yo las integro.
